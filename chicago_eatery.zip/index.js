function openNav(){
    document.getElementsByClassName("sidebar").style.width = "250px";
    document.getElementsByClassName("main").style.marginLeft = "250px";
}

function closeNav(){
    document.getElementsByClassName("sidenav").style.width = "0";
    document.getElementsByClassName("main").style.marginLeft = "0";
}